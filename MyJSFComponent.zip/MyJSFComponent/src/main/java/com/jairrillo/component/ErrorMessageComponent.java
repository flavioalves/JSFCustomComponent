package com.jairrillo.component;

import java.io.IOException;
import java.util.Iterator;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponentBase;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;

/**
 * @author Jair Rillo Junior
 */
public class ErrorMessageComponent extends UIComponentBase {

    public static final String COMPONENT_TYPE = "com.jairrillo.component.errorMessage";
    public static final String RENDER_TYPE = "com.jairrillo.component.ErrorMessageComponent";    

    /**
     * constructor for the component.
     */
    public ErrorMessageComponent() {
        super();
        setRendererType(null);
    }

    @Override
    public String getFamily() {
        return COMPONENT_TYPE;
    }

	@SuppressWarnings("unchecked")
	@Override
    public void encodeBegin(FacesContext context) throws IOException {
        Iterator iter = context.getMessages();
        //check if there are messages
        if (iter.hasNext()) {
        	StringBuffer messages = new StringBuffer();
            ResponseWriter writer = context.getResponseWriter();
            //going through all messages
            while (iter.hasNext()) {
                FacesMessage msg = (FacesMessage) iter.next();
                messages.append(msg.getSummary() + "<br />");
            }
            //print out the result
            writer.write("<div style='border: 1px solid black; width: 100%;'>");
            writer.write(messages.toString());
            writer.write("</div>");
        }
    }

    @Override
    public void encodeEnd(FacesContext context) throws IOException {
        super.encodeEnd(context);
    }

}
